/*(a) Each candidate has a name, an address, and an age. The application reads
        this information first, saves it in objects, and uses the information to count
        votes, which are now submitted by typing the candidates’ names.*/

import javax.swing.*;
/** VoteCount tallies the votes for election candidates.
 * input: a sequence of votes, terminated by a -1
 * output: the listing of the candidates and their tallied votes */
public class VoteCount {
    public static void main(String[] args) {
        int num_candidates = 4; // how many candidates
        int[] votes = new int[num_candidates]; // holds the votes;
// recall that each element is initialized to 0
// collect the votes:

    String[] name = new String[num_candidates]; // (*) holds candidates' names
        for (int i = 0; i != num_candidates; i = i + 1) {
                name[i] = JOptionPane.showInputDialog("Type name of Candidate " + i);
                }

                boolean processing = true;
                while (processing)
// invariant: all votes read have been tallied in array votes
                {
                int v = Integer.parseInt(JOptionPane.showInputDialog("Vote for (0, 1, 2, 3):"));
                if (v >= 0 && v < votes.length) // is it a legal vote?
        {
        votes[v] = votes[v] + 1;
        } else {
        processing = false;
        { System.out.println("VoteCount error: vote " + v); }
           }
         }
        for (int i = 0; i != num_candidates; i = i + 1) {
        System.out.println("Candidate " + name[i] + " has " + votes[i] + " votes");
        }
    }
}
